package com.edu.slu.sensor;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

/**
 * Thread that registers, unregisters the GPS and processes the Location data
 * Created by sashank on 1/22/15.
 */
public class LocationThread extends Thread implements LocationListener {

    private Context context = null;
    private LocationManager location_manager = null;

    /**
     * Default constructor
     * @param context
     */
    public LocationThread(Context context) {
        this.context = context;
    }

    /**
     * Register the GPS and network location provider
     */
    @Override
    public void run() {
        super.run();
        Looper.prepare();

        // Obtain an instance of the location service and request updates to locations from both the network and gps provider
        location_manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if ((ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) &&
            (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
            location_manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            location_manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        }

        Looper.loop();
    }

    @Override
    public void onLocationChanged(Location location) {
        LocationObject location_obj = new LocationObject(System.currentTimeMillis(), location.getAccuracy(), location.getLatitude(), location.getLongitude(), location.getAltitude());
        // Write the location data if the recording has started
        if (MainActivity.is_recording) {
            location_obj.write();
        }

        // Check if the thread has been interrupted
        if (this.isInterrupted()) {
            // Request cancellation to updates to location from the location service
            location_manager.removeUpdates(this);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onProviderDisabled(String provider) {}

}