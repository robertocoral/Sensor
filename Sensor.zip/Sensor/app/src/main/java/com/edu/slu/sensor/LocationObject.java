package com.edu.slu.sensor;

/**
 * This class represents attributes and methods pertaining to the locations
 * Created by sashank on 12/2/15.
 */
public class LocationObject {
    private long time = 0;
    private float accuracy = 0;
    private double latitude = 0;
    private double longitude = 0;
    private double altitude = 0;

    /**
     * Default constructor
     * @param system_time
     * @param accuracy
     * @param latitude
     * @param longitude
     * @param altitude
     */
    public LocationObject(long system_time, float accuracy, double latitude, double longitude, double altitude) {
        this.time = system_time - MainActivity.start_time;
        this.accuracy = accuracy;
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = altitude;
    }

    /**
     * Write the location data to a file
     */
    public void write() {
        // If this is a new file, write header to file
        if(!FileUtils.exists(MainActivity.loc_file)) {
            String header = "System Time,Accuracy,Latitude,Longitude,Altitude\n";
            FileUtils.write(MainActivity.loc_file, header);
        }

        // Create a string line with location data and write the data to file
        String line = String.format("%d,%f,%f,%f,%f\n", this.time, this.accuracy, this.latitude, this.longitude, this.altitude);
        FileUtils.write(MainActivity.loc_file, line);
    }
}
